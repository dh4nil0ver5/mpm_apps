import 'package:flutter/cupertino.dart';

class AuthRepository {
  late BuildContext context;

  Future<void> login() async {
    print("login on progress");
    Future.delayed(Duration(seconds: 3));
  }
}
