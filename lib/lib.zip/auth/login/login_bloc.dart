import 'dart:math';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mpm_apps/auth/AuthRepository.dart';
import 'package:mpm_apps/auth/FormSubmissionStatus.dart';
import 'package:mpm_apps/auth/login/login_event.dart';
import 'package:mpm_apps/auth/login/login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final AuthRepository authRepo;
  LoginBloc({required this.authRepo}) : super(LoginState()) {
    on<LoginUsernameChanged>((event, emit) {
      state.copyWith(username: event.username);
    });
    on<LoginPasswordChanged>((event, emit) {
      state.copyWith(password: event.password);
    });
    on<LoginSubmitted>((event, emit) async {
      state.copyWith(formStatus: FormSubmitting());
      try {
        await authRepo.login();
        state.copyWith(formStatus: SubmissionSuccess());
        
      } catch (e) {
        print(e.toString());
        // yield state.copyWith(formStatus: SubmissionFailed(e));
      }
    });
  }

  // @override
  // Stream<LoginState> mapEventToState(LoginEvent event) async* {
  //   if(event is LoginUsernameChanged){
  //     yield state.copyWith(username:  event.username);
  //   }else if(event is LoginPasswordChanged){
  //     yield state.copyWith(password: event.password);
  //   }else if(event is LoginSubmitted){
  //     yield state.copyWith(formStatus: FormSubmitting());
  //     try {
  //       await authRepo.login();
  //       yield state.copyWith(formStatus: SubmissionSuccess());
  //     } catch (e) {
  //       print(e.toString());
  //       // yield state.copyWith(formStatus: SubmissionFailed(e));
  //     }
  //   }
  // }
}
