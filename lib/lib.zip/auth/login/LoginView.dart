import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mpm_apps/auth/AuthRepository.dart';
import 'package:mpm_apps/auth/FormSubmissionStatus.dart';
import 'package:mpm_apps/auth/login/login_bloc.dart';
import 'package:mpm_apps/auth/login/login_event.dart';
import 'package:mpm_apps/auth/login/login_state.dart';
import 'package:mpm_apps/page/SecondScreen.dart';

class LoginView extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();

  bool _isObscure = true;

  late String _email;
  late String _password;
  bool _value = false;
  int val = -1;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LoginBloc, LoginState>(
      builder: (context, state) {
        return Scaffold(
            body: _loginForm(context));
      },
    );
    // Scaffold(
    //   body: MultiBlocProvider(
    //     providers: [
    //       BlocProvider<LoginBloc>(
    //         create: (BuildContext context) => LoginBloc(
    //           authRepo: context.read<AuthRepository>(),
    //         ),
    //       ),
    //     ],
    //     child: _loginForm(context),
    //   ),
    // );
  }

  Widget _loginForm(BuildContext context) {
    return BlocBuilder<LoginBloc, LoginState>(builder: (context, state) {
      return Form(
          key: _formKey,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                _LabelBrand(context),
                Container(height: 10),
                _username(context),
                Container(height: 10),
                _Password(context),
                Container(height: 10),
                _levelUser(context),
                Container(height: 10),
                _loginButton(context),
                Container(height: 10),
                _rememberLogin(context)
              ],
            ),
          ));
    });
  }

  Widget _LabelBrand(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(8.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        // ignore: prefer_const_literals_to_create_immutables
        children: [
          Text(
            "MPM",
            style: TextStyle(fontFamily: 'Verdana', fontSize: 80),
          ),
          Text("DISTRIBUTOR")
        ],
      ),
    );
  }

  Widget _username(BuildContext context) {
    return BlocBuilder<LoginBloc, LoginState>(builder: (context, state) {
      return TextFormField(
          autovalidateMode: AutovalidateMode.onUserInteraction,
          onEditingComplete: () => TextInput.finishAutofillContext(),
          textInputAction: TextInputAction.next,
          decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(20.0),
              ),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.grey, width: 1),
                borderRadius: BorderRadius.circular(25.0),
              ),
              filled: true,
              hintStyle: TextStyle(color: Colors.grey[800]),
              hintText: "username",
              fillColor: Colors.white70),
          // validator: (value) =>
          //     state.isValidUsername ? null : 'username is too short',
          onChanged: (value) => context
              .read<LoginBloc>()
              .add(LoginUsernameChanged(username: value)));
    });
  }

  Widget _Password(BuildContext context) {
    return BlocBuilder<LoginBloc, LoginState>(builder: (context, state) {
      return TextFormField(
        obscureText: _isObscure,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        onEditingComplete: () => TextInput.finishAutofillContext(),
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20.0),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey, width: 1),
              borderRadius: BorderRadius.circular(25.0),
            ),
            suffixIcon: GestureDetector(
              // onLongPress: () => inContact,
              // onLongPressUp: () => outContact(),
              child: Icon(_isObscure ? Icons.visibility : Icons.visibility_off),
            ),
            filled: true,
            hintStyle: TextStyle(color: Colors.grey[800]),
            hintText: "password",
            fillColor: Colors.white70),
        // validator: (value) =>
        //     state.isValidUsername ? 'kosong' : 'password is too short',
        onChanged: (value) => context.read<LoginBloc>().add(
              LoginPasswordChanged(password: value),
            ),
      );
    });
  }

  Widget _levelUser(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Expanded(
          child: SizedBox(
            child: Container(
              // color: Color(0xFFCC1105),
              child: ListTile(
                title: Text(
                  "user",
                  style: TextStyle(fontSize: 10),
                ),
                leading: Radio(
                  value: 1,
                  groupValue: val,
                  onChanged: (value) {},
                  activeColor: Colors.green,
                ),
              ),
            ),
          ),
        ),
        Expanded(
          child: SizedBox(
            child: Container(
              // color: Color(0xFFCC1105),
              child: ListTile(
                title: Text(
                  "Security",
                  style: TextStyle(fontSize: 10),
                ),
                leading: Radio(
                  value: 1,
                  groupValue: val,
                  onChanged: (value) {},
                  activeColor: Colors.green,
                ),
              ),
            ),
          ),
        )
      ],
    );
  }

  Widget _loginButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          BlocBuilder<LoginBloc, LoginState>(builder: (context, state) {
            return state.formStatus is FormSubmitting
                ? CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState == null) {
                        context.read<LoginBloc>().add(LoginSubmitted());
                      } else if (_formKey.currentState!.validate()) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("waiting .... !")),
                        );
                        MaterialPageRoute(
                          builder: (_) => SecondScreen(),
                        );
                      }
                    },
                    child: Container(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: Text('Login')));
          }),
          ElevatedButton(
              onPressed: () {},
              child: Container(
                  width: MediaQuery.of(context).size.width * 0.1,
                  child: Icon(Icons.fingerprint))),
          ElevatedButton(
              onPressed: () {},
              child: Container(
                  width: MediaQuery.of(context).size.width * 0.1,
                  child: Icon(Icons.face_unlock_sharp))),
        ],
      ),
    );
  }

  Widget _rememberLogin(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text("Lupa Password ?"),
          TextButton(onPressed: () {}, child: Text("Click here !"))
        ],
      ),
    );
  }

  // void inContact() {
  //   setState() => {_isObscure = !_isObscure};
  // }

  // void outContact() {
  //   setState() => {_isObscure = _isObscure};
  // }
}
