import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mpm_apps/auth/login/login_bloc.dart';
import 'package:mpm_apps/auth/login/login_state.dart';

class SecondScreen extends StatefulWidget {
  const SecondScreen({Key? key}) : super(key: key);

  @override
  State<SecondScreen> createState() => _YellowBirdState();
}

class _YellowBirdState extends State<SecondScreen> {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LoginBloc, LoginState>(
      builder: (context, state) {
        return Scaffold(
          body: Center(child: Text("s")),
        );
      },
    );
  }
}
